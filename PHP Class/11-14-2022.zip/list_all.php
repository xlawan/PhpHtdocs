<html>
	<head>
		<title>List All Items</title>
	</head>
	<body>
		<?php
			$con = mysqli_connect("localhost", "root", "", "inventory");
			if($con)
			{
				$sql = " select 
							item.iid,
							item.description,
							item.umsr,
							category.description,
							item.qtyonhand,
							item.price
						 from
							item inner join category
								on item.cid = category.cid
						 order by
							item.description
				";
				$records = mysqli_query($con, $sql);
				if(mysqli_num_rows($records) > 0)
				{
					echo "<table border='1'>";
					echo "	<tr>";
					echo "		<th>Seq. No.</th>";
					echo "		<th>Item ID</th>";
					echo "		<th>Description</th>";
					echo "		<th>Unit of Measure</th>";
					echo "		<th>Category</th>";
					echo "		<th>Qty. on Hand</th>";
					echo "		<th>Price</th>";
					echo "	</tr>";
					
					$seq = 1;
					while($rec = mysqli_fetch_array($records))
					{
						
						echo "<tr>";
						echo "		<td>".$seq.".</td>";
						echo "		<td>".$rec[0]."</td>";
						echo "		<td>".$rec[1]."</td>";
						echo "		<td>".$rec[2]."</td>";
						echo "		<td>".$rec[3]."</td>";
						echo "		<td align='right'>".$rec[4]."</td>";
						echo "		<td align='right'>".$rec[5]."</td>";
						echo "</tr>";
						$seq++;
					}
					
					
					echo "</table>";
				}
				else 
				{
					echo "<p>No records found...</p>";
				}
				
			}
			else 
			{
				echo "<p>Error connecting to DB...</p>";
			}
			mysqli_close($con);			
		
		?>
	
	</body>
</html>